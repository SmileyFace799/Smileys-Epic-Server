ServerEvents.tags("item", event => {
    for (const color of global.colors) {
        event.add("waystones:portstones", `waystones:${color}_portstone`);

        event.remove("c:dyes/orange", "swem:cantazarite_dye");
    }
});

ServerEvents.tags("block", event => {
    event.add("minecraft:beacon_base_blocks", "swem:cantazarite_block");
})
